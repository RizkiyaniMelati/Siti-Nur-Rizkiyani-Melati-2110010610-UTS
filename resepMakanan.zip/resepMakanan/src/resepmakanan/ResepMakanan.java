/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package resepmakanan;

import forms.*;
import database.koneksi;
import java.sql.SQLException;

/**
 *
 * 
 */
public class ResepMakanan {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
//        new koneksi();
        new frameResep().setVisible(true);
    }
    
}
